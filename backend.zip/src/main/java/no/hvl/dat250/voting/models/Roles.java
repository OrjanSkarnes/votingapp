package no.hvl.dat250.voting.models;

import java.util.Optional;

public enum Roles {
    ROLE_ADMIN,
    ROLE_USER;

}
